package antoniotodarello.progettovenerdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgettovenerdiApplicationTests {

	@Test
	void contextLoads() {
	}

}
